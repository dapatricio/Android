/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import java.sql.*;
import java.sql.DriverManager;

/**
 *
 * @author Daniel Peñarreta
 * Cristian Mendoza
 * Jairo Valle
 * 
 * Fecha: 21/07/2016
 */
public class ConexionBD {
    public static Connection con;
    
    

    private Connection conexion;

    public Connection getConexion() {
        return conexion;
    }

    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }

    public ConexionBD conectar() {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String BaseDeDatos = "jdbc:oracle:thin:@localhost:1521:xe";

            conexion = DriverManager.getConnection(BaseDeDatos, "HR", "hr");
            if (conexion != null) {
                System.out.println("Conexion exitosa conectar!");
            } else {
                System.out.println("Conexion fallida conectar!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }
    public ConexionBD conectarTripletas() {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String BaseDeDatos = "jdbc:oracle:thin:@localhost:1521:xe";

            conexion = DriverManager.getConnection(BaseDeDatos, "SYSTEM", "primos14");
            if (conexion != null) {
                System.out.println("Conexion exitosa tripletas!");
            } else {
                System.out.println("Conexion fallida tripletas!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }
}
